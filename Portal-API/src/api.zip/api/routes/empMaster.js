// global imports
const express = require('express');

// local imports
const { empMasterController } = require('../controllers');

const router = express.Router();

// Route create a new employee
router.post('/add', empMasterController.addEmployee);
// Route update employee by id
router.put('/update/:emp_id', empMasterController.updateEmployee);
// Route get all employees
router.get('/findAll', empMasterController.getAllEmployees);
// Route get all employees whose status is active
router.get('/findAllActive', empMasterController.getActiveEmployee);
// Route to make status active to deactive
router.patch('/activeToDeactive/:emp_id', empMasterController.update);
module.exports = router;