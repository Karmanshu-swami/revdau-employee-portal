// global imports
const express = require('express');

// local imports
const { KraController } = require('../controllers');

const router = express.Router();

// add kra
router.post('/add', KraController.addKra);
//update comment
router.put('/update/:kra_id/:emp_id', KraController.updateComment);
//update employees acknowledgement
router.put('/updateAck/:kra_id/:user_id', KraController.updateAck);


module.exports = router;