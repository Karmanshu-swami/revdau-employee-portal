const utils = require('../../utils/response');
const { getDbManager } = require('../models');


//  add kra
exports.addKra = async (req, res) => {
    console.log('addkra() triggered ....');
  
    const { Kra } = await getDbManager();
    
    try {
      const data = req.body;
      const newKra = await Kra.create(data);
      res.send(utils.createSuccess(newKra))
    } catch (error) {
      res.send(utils.createError(error))
    }
  };

//update manager_comment 
exports.updateComment = async (req, res) => {
  console.log('updateManagerComment() triggered ....');

  const { Kra } = await getDbManager();
  const manager_comment = req.body
  try {
     const updateKra = await Kra.update(manager_comment,{
      where: {
          kra_id: req.params.kra_id,
          emp_id: req.params.emp_id
       }
    });
    res.send(utils.createSuccess(updateKra))
  } catch (error) {
    res.send(utils.createError(error))
  }
 };

 //update acknowledgement
exports.updateAck = async (req, res) => {
  console.log('updateAcknowledgement() triggered ....');

  const { Kra } = await getDbManager();
  const emp_acknowledgement = req.body
  try {
     const updateKra = await Kra.update(emp_acknowledgement,{
      where: {
          kra_id: req.params.kra_id,
          user_id: req.params.user_id
       }
    });
    res.send(utils.createSuccess(updateKra))
  } catch (error) {
    res.send(utils.createError(error))
  }
 };