const utils = require('../../utils/response');
const { getDbManager } = require('../models');

//  create a new employee
exports.addEmployee = async (req, res) => {
  console.log('addemployee() triggered ....');

  const { Employee_master } = await getDbManager();
  try {
    const data = req.body;
    const newEmployee = await Employee_master.create(data);
    res.send(utils.createSuccess(newEmployee))
  } catch (error) {
    res.send(utils.createError(error))
  }
};

//  update employee by id
exports.updateEmployee = async (req, res) => {
  console.log('update() triggered ....');

  const { Employee_master } = await getDbManager();
  try {
     const updateEmployee = await Employee_master.update(req.body, {
      where: {
          emp_id: req.params.emp_id
       }
    });
    res.send(utils.createSuccess(updateEmployee))
  } catch (error) {
    res.send(utils.createError(error))
  }
 };

 //find all employees
 exports.getAllEmployees = async (req, res) => {
  console.log('getAllEmployeeProfile() triggered ....');

  const { Employee_master } = await getDbManager();
  try {
    const findAllEmployee = await Employee_master.findAll();
    res.send(utils.createSuccess(findAllEmployee))
  } catch (error) {
    res.send(utils.createError(error))
  }
};

//find all employees whose status is active
exports.getActiveEmployee = async (req, res) => {
  console.log('getAllActiveEmployeeProfile() triggered ....');

  const { Employee_master } = await getDbManager();
  try {
    const findEmployee = await Employee_master.findAll({
      where: {
        status: req.body.status
      }
    });
    res.send(utils.createSuccess(findEmployee))
  } catch (error) {
    res.send(utils.createError(error))
  }
};


//make status active to deactive
exports.update = async (req, res) => {
  console.log('activeToDeactive() triggered ....');

  const { Employee_master } = await getDbManager();
  // const status = req.body
  // console.log(status)
  // console.log(req.params.emp_id)
  try {
     const updateEmployee = await Employee_master.update({status:"deactive"}, {
      where: {
          emp_id: req.params.emp_id
       }
    });
    res.send(utils.createSuccess(updateEmployee))
  } catch (error) {
    res.send(utils.createError(error))
  }
 };