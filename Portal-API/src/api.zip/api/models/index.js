// local imports

const { DbDatasource } = require('../../datasources');
// All Schemas
const userSchema = require('./user');
const empMasterSchema = require('./empMaster');
const kraSchema = require('./kra');

let dbManager;

exports.getDbManager = () => {
  if (dbManager) return Promise.resolve(dbManager);
  return createDBManager();
};

async function createDBManager() {
  console.log('createDBManager() triggered ....');

  try {
    const dbConn = await DbDatasource;

    const User = dbConn.define('user', userSchema.schema, userSchema.options);
    const Employee_master = dbConn.define('employee_master', empMasterSchema.schema, empMasterSchema.options);
    const Kra = dbConn.define('kra', kraSchema.schema, kraSchema.options);
    dbManager = {
      User,
      Employee_master,
      Kra,
    };

    return dbManager;
  } catch (error) {
   console.log('Error occured while creating DB Manager !!!');
    console.log(error);
    process.exit(0);
  }
}

// create DB Manager
createDBManager();
